#!/usr/bin/env bash
set -euo pipefail

package_root="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
setup_file="$package_root/install/setup.bash"

if [[ ! -f "$setup_file" ]]; then
  echo "Run ./build.sh first." >&2
  exit 1
fi

source "$setup_file"
exec ros2 launch fr5_unity_endpoint fr5_with_endpoint.launch.py "$@"
